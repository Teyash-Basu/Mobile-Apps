package com.example.rs_to_dollar_convertor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private EditText editText;
    private TextView Result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.button);
        editText=findViewById(R.id.editTextNumber);
        Result=findViewById(R.id.textView3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "Enter Rs", Toast.LENGTH_SHORT).show();
                String s = editText.getText().toString();
                int Rs = Integer.parseInt(s);
                double Dollar = Rs / 79.85;
                Result.setText(Rs +" in Dollar = "+Dollar);
                Toast.makeText(MainActivity.this, "Conversion successful", Toast.LENGTH_SHORT).show();

            }
        });
    }
}