
//public void showToast(View view) {
//    Toast toast = Toast.makeText(this,R.string.toast_message,Toast.LENGTH_SHORT);
//    toast.show();
//    }
//public void countUp(View view){
//    mCount++;
//    if(mShowCount != null){
//        mShowCount.setText(Integer.toString(mCount));
//        }
//    }
//
//}

package com.example.hellotoast;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;
        import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button toast;
    private Button count;
    private TextView text;
    private Button reset;
    int num =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toast =findViewById(R.id.toast);
        count=findViewById(R.id.count);
        text=findViewById(R.id.textView);
        reset=findViewById(R.id.button_reset);
        toast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Hello Toast", Toast.LENGTH_SHORT).show();
            }
        });
        count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num++;
                text.setText(Integer.toString(num));
//      OR        String s =text.getText().toString();
//                if(s!=null){
//                    text.setText(Integer.toString(num));
//                }
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num=0;
                text.setText(Integer.toString(num));
            }
        });
    }
}